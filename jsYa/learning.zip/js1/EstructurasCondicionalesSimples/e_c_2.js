// declaration of variables
let key1, key2;

key1 = parseInt(prompt("Ingresa la primera clave: "));
key2 = parseInt(prompt("Ingresa la segunda clave: "));

if(key1 == key2){
    alert("las claves son iguales");
}else{
    alert("Las claves no son iguales");
}