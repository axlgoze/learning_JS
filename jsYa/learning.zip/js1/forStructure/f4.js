// Desarrollar un programa que muestre la tabla de multiplicar del 5 (del 5 al 50).

// for(let f=0;f<50;f++){
//     let m=f*5;
//     document.write(m+" ");
//     if(m==50){
//         break;
//     }
// }

let number=5;
for(let f=0;f<=10;f++){
    document.write(number + " ");
    number = number + 5;
}

