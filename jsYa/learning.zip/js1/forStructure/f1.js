for (let f = 1; f <= 10; f++) {
    document.write(f + " ");
}