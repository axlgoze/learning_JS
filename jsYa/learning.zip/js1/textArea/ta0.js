// Confeccionar una página de visitas a un sitio, solicitar ingresar el nombre de una persona, su mail y los comentarios (TEXTAREA). Mostrar luego llamando a la función alert los datos ingresados.

function validateComment(){
    let opinion = document.getElementById('textArea1').value;
    alert(opinion);
}