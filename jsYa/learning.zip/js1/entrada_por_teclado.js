        let name;
        let age;
        // input
        name = prompt('Ingresa tu nombre: ');
        age = prompt('Ingresa tu edad: ');
        // impresion
        document.write("Hola "+ name);
        document.write('<br>');
        document.write("So you're "+ age);