let day,month,year;

day=parseInt(prompt("Enter day"));
month=parseInt(prompt("Enter month"));
year=parseInt(prompt("Enter year"));

if(day==24 && month==12){
    document.write("Happy Christmas");
}else{
    document.write("Another simple day");
}

