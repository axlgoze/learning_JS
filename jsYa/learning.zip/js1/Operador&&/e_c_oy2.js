let v1,v2,v3;
v1=parseInt(prompt("Enter a number: "));
v2=parseInt(prompt("Enter a number: "));
v3=parseInt(prompt("Enter a number: "));

if(v1==v2 && v2==v3){
    result=(v1+v2)*v3
    document.write(result);
}