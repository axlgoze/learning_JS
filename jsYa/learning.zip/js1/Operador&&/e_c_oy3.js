let v1,v2,v3;
v1=parseInt(prompt("Enter a number: "));
v2=parseInt(prompt("Enter a number: "));
v3=parseInt(prompt("Enter a number: "));

if(v1<10 && v2<10 && v3<10){
    document.write("All numbers are menores a 10");
}