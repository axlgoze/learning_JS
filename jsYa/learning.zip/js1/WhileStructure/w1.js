let x = 0;
let y = 11;
let n = 1;
while(x<25){
    y=y+11;
    document.write("<br>");
    document.write(n+".- " + y);
    x=x+1;
    n=n+1;
}