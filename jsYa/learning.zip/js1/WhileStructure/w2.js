let x=0;
let n=1;
while(x<=500){
    x=x+8;
    document.write("<br>")
    document.write(n+".- " + x);
    n=n+1;
}