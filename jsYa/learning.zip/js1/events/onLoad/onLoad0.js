
// function activateControl() {
//     document.getElementById('first-control').focus();
// }

// El evento onLoad se ejecuta al final de la carga de la página en el navegador.

// Confeccionar una página que muestre un mensaje con la función alert inmediatamente después que se cargue.

function activateControl(){
    confirm("ON LOAD EVENT WORKING !")
}