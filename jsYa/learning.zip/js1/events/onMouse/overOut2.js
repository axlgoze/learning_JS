// Modificar el segundo problema resuelto (las casillas de la tabla que cambian el color cuando ingresamos con el mouse) para permitir llamar mediante hipervínculos a distintos programas que administran web-mail (gmail, hotmail y yahoo)

function pintar(objeto, col) {
    objeto.style.backgroundColor = col;
}