function paint(color){
    let container = document.getElementById('container');
    container.style.backgroundColor = color;
}