function goBack(){
    window.history.back()
}
function goForward(){
    window.history.go()
}
function goTo(){
    window.history.go()
}