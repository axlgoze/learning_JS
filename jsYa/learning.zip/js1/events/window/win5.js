// navigator object returns web browser info.
document.write('Valores de las propiedades del objeto navigator:<br>');
        document.write('appName :' + navigator.appName + '<br>');
        document.write('appVersion :' + navigator.appVersion + '<br>');
        document.write('cookieEnabled :' + navigator.cookieEnabled + '<br>');
        document.write('plugins :' + navigator.plugins.length + '<br>');
        console.log(navigator.plugins);