let number;

number = parseInt(prompt("Ingresa un número"));

if (number >=10) {
    document.write("the number has two digits or more.")
} else {
    document.write("The number has only one digit.")
}