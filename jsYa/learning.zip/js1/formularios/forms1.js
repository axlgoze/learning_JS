// Crear un formulario con tres botones con las leyendas "1", "2" y "3". Mostrar un mensaje indicando qué botón se presionó. 

function printMessage(message){

    alert("The button number "+message+" was pressed!");
}