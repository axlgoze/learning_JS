
let lado, perimetro;

input = parseInt(prompt("Ingresa el valor del lado del cuadrado:"));

perimetro = input*4;

document.write("El perímetro del cuadrado es: " + perimetro);
