// modifies the original array

let vec = [10, 20, 30, 40];
let vec2 = vec.concat(1, 2, 3);

console.log(vec2);