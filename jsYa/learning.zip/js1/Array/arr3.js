let vector1 = new Array();
vector1[0] = 1;

let vector2 = [];
vector2[0] =  1;

let vector3 = new Array(5);
vector3[0] = 1;

let vector4 = new Array(1, 70, 'Axel');

let vector5 = [1, 50, 'Brayan'];

document.write(vector1[0]+'<br>');
document.write(vector2[0]+'<br>');
document.write(vector3[0]+'<br>');
document.write(vector4[0]+'<br>');
document.write(vector5[0]+'<br>');