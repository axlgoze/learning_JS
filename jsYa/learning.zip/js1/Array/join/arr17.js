// Crear un vector con los datos de 5 personas. 
// Luego imprimir por pantalla uno abajo de otro utilizando el método join 
// para generar un string y agregarle entre elementos la etiqueta html <br>.

let arr = new Array(5);

arr = [
    "saul",
    "Casandra",
    "Paolo",
    "brenda",
    "sofia"
];


console.log(arr.join("➡"));